function [ mono ] = extract_and_play_mono_audio( bb )
%EXTRACT_AND_PLAY_MONO_AUDIO Summary of this function goes here
%   Detailed explanation goes here

    fs = 190000;
    f6 = fir1(300,15000/fs*2);
    mono = filter(f6,1,bb);
    mono = mono/max(mono);
    mono48k = resample(mono,48000,190000);
    sound(mono48k,48000);
end

