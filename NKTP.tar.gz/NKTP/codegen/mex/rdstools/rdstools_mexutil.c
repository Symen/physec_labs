/*
 * rdstools_mexutil.c
 *
 * Code generation for function 'rdstools_mexutil'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_mexutil.h"

/* Function Definitions */
void error(const emlrtStack *sp, const mxArray *b, emlrtMCInfo *location)
{
  const mxArray *pArray;
  pArray = b;
  emlrtCallMATLABR2012b(sp, 0, NULL, 1, &pArray, "error", TRUE, location);
}

const mxArray *message(const emlrtStack *sp, const mxArray *b, emlrtMCInfo
  *location)
{
  const mxArray *pArray;
  const mxArray *m6;
  pArray = b;
  return emlrtCallMATLABR2012b(sp, 1, &m6, 1, &pArray, "message", TRUE, location);
}

/* End of code generation (rdstools_mexutil.c) */
