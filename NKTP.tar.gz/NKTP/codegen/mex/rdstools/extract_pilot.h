/*
 * extract_pilot.h
 *
 * Code generation for function 'extract_pilot'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __EXTRACT_PILOT_H__
#define __EXTRACT_PILOT_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void b_eml_xaxpy(real_T a, const real_T x[301], real_T y[301]);
extern void eml_xaxpy(int32_T n, real_T a, const emxArray_real_T *x, int32_T ix0, emxArray_real_T *y, int32_T iy0);
extern void extract_pilot(const emlrtStack *sp, const emxArray_real_T *bb_signal, emxArray_real_T *pilot);
#endif
/* End of code generation (extract_pilot.h) */
