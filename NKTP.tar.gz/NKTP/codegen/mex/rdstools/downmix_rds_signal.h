/*
 * downmix_rds_signal.h
 *
 * Code generation for function 'downmix_rds_signal'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __DOWNMIX_RDS_SIGNAL_H__
#define __DOWNMIX_RDS_SIGNAL_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void downmix_rds_signal(const emlrtStack *sp, const emxArray_real_T *pilot, const emxArray_real_T *rds, emxArray_real_T *rds_bb);
#endif
/* End of code generation (downmix_rds_signal.h) */
