MATLAB="/usr/local/MATLAB/R2013b"
Arch=glnxa64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/home/nktp/.matlab/R2013b"
OPTSFILE_NAME="./mexopts.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for rdstools" > rdstools_mex.mki
echo "CC=$CC" >> rdstools_mex.mki
echo "CFLAGS=$CFLAGS" >> rdstools_mex.mki
echo "CLIBS=$CLIBS" >> rdstools_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> rdstools_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> rdstools_mex.mki
echo "CXX=$CXX" >> rdstools_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> rdstools_mex.mki
echo "CXXLIBS=$CXXLIBS" >> rdstools_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> rdstools_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> rdstools_mex.mki
echo "LD=$LD" >> rdstools_mex.mki
echo "LDFLAGS=$LDFLAGS" >> rdstools_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> rdstools_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> rdstools_mex.mki
echo "Arch=$Arch" >> rdstools_mex.mki
echo OMPFLAGS= >> rdstools_mex.mki
echo OMPLINKFLAGS= >> rdstools_mex.mki
echo "EMC_COMPILER=" >> rdstools_mex.mki
echo "EMC_CONFIG=optim" >> rdstools_mex.mki
"/usr/local/MATLAB/R2013b/bin/glnxa64/gmake" -B -f rdstools_mex.mk
