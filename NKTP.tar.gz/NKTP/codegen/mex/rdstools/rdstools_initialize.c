/*
 * rdstools_initialize.c
 *
 * Code generation for function 'rdstools_initialize'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_initialize.h"

/* Variable Definitions */
static const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* Function Definitions */
void rdstools_initialize(emlrtStack *sp, emlrtContext *aContext)
{
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, aContext, NULL, 1);
  sp->tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(sp, FALSE, 0U, 0);
  emlrtEnterRtStackR2012b(sp);
  emlrtLicenseCheckR2012b(sp, "Signal_Toolbox", 2);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (rdstools_initialize.c) */
