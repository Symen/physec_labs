/*
 * rdstools_initialize.h
 *
 * Code generation for function 'rdstools_initialize'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __RDSTOOLS_INITIALIZE_H__
#define __RDSTOOLS_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void rdstools_initialize(emlrtStack *sp, emlrtContext *aContext);
#endif
/* End of code generation (rdstools_initialize.h) */
