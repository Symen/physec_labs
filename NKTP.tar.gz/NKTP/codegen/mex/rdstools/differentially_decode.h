/*
 * differentially_decode.h
 *
 * Code generation for function 'differentially_decode'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __DIFFERENTIALLY_DECODE_H__
#define __DIFFERENTIALLY_DECODE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void differentially_decode(const emlrtStack *sp, const emxArray_boolean_T *in, emxArray_boolean_T *out);
#endif
/* End of code generation (differentially_decode.h) */
