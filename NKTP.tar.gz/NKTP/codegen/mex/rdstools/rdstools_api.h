/*
 * rdstools_api.h
 *
 * Code generation for function 'rdstools_api'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __RDSTOOLS_API_H__
#define __RDSTOOLS_API_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void differentially_decode_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void downmix_rds_signal_api(emlrtStack *sp, const mxArray * const prhs[2], const mxArray *plhs[1]);
extern void extract_pilot_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void extract_rds_signal_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void frequency_demodulation_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void generate_bit_clock_from_pilot_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void lowpass_filter_rds_baseband_signal_api(emlrtStack *sp, const mxArray * const prhs[1], const mxArray *plhs[1]);
#endif
/* End of code generation (rdstools_api.h) */
