/*
 * extract_rds_signal.h
 *
 * Code generation for function 'extract_rds_signal'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __EXTRACT_RDS_SIGNAL_H__
#define __EXTRACT_RDS_SIGNAL_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void extract_rds_signal(const emlrtStack *sp, const emxArray_real_T *bb_signal, emxArray_real_T *rds);
#endif
/* End of code generation (extract_rds_signal.h) */
