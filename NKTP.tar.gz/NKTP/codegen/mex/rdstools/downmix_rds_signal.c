/*
 * downmix_rds_signal.c
 *
 * Code generation for function 'downmix_rds_signal'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_emxutil.h"

/* Variable Definitions */
static emlrtRTEInfo c_emlrtRTEI = { 1, 23, "downmix_rds_signal",
  "/home/nktp/Documents/NKTP/downmix_rds_signal.m" };

static emlrtECInfo c_emlrtECI = { -1, 5, 14, "downmix_rds_signal",
  "/home/nktp/Documents/NKTP/downmix_rds_signal.m" };

/* Function Definitions */
void downmix_rds_signal(const emlrtStack *sp, const emxArray_real_T *pilot,
  const emxArray_real_T *rds, emxArray_real_T *rds_bb)
{
  int32_T i3;
  int32_T loop_ub;

  /* DOWNMIX_RDS_SIGNAL Summary of this function goes here */
  /*    Detailed explanation goes here */
  i3 = rds_bb->size[0];
  rds_bb->size[0] = pilot->size[0];
  emxEnsureCapacity(sp, (emxArray__common *)rds_bb, i3, (int32_T)sizeof(real_T),
                    &c_emlrtRTEI);
  loop_ub = pilot->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    rds_bb->data[i3] = pilot->data[i3] * pilot->data[i3];
  }

  i3 = rds_bb->size[0];
  loop_ub = pilot->size[0];
  emlrtSizeEqCheck1DFastR2012b(i3, loop_ub, &c_emlrtECI, sp);
  i3 = rds_bb->size[0];
  emxEnsureCapacity(sp, (emxArray__common *)rds_bb, i3, (int32_T)sizeof(real_T),
                    &c_emlrtRTEI);
  loop_ub = rds_bb->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    rds_bb->data[i3] *= pilot->data[i3];
  }

  i3 = rds_bb->size[0];
  loop_ub = rds->size[0];
  emlrtSizeEqCheck1DFastR2012b(i3, loop_ub, &c_emlrtECI, sp);
  i3 = rds_bb->size[0];
  emxEnsureCapacity(sp, (emxArray__common *)rds_bb, i3, (int32_T)sizeof(real_T),
                    &c_emlrtRTEI);
  loop_ub = rds_bb->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    rds_bb->data[i3] *= rds->data[i3];
  }
}

/* End of code generation (downmix_rds_signal.c) */
