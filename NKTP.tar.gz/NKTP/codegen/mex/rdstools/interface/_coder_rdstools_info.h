/*
 * _coder_rdstools_info.h
 *
 * Code generation for function 'differentially_decode'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef ___CODER_RDSTOOLS_INFO_H__
#define ___CODER_RDSTOOLS_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_rdstools_info.h) */
