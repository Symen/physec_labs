/*
 * rdstools_api.c
 *
 * Code generation for function 'rdstools_api'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_api.h"
#include "rdstools_emxutil.h"

/* Variable Definitions */
static emlrtRTEInfo l_emlrtRTEI = { 1, 1, "rdstools_api", "" };

/* Function Declarations */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_boolean_T *y);
static const mxArray *b_emlrt_marshallOut(emxArray_real_T *u);
static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *pilot, const
  char_T *identifier, emxArray_real_T *y);
static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *in, const
  char_T *identifier, emxArray_creal_T *y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *in, const
  char_T *identifier, emxArray_boolean_T *y);
static const mxArray *emlrt_marshallOut(emxArray_boolean_T *u);
static void f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_creal_T *y);
static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_boolean_T *ret);
static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);
static void i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_creal_T *ret);

/* Function Definitions */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_boolean_T *y)
{
  g_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_emlrt_marshallOut(emxArray_real_T *u)
{
  const mxArray *y;
  static const int32_T iv10[1] = { 0 };

  const mxArray *m5;
  y = NULL;
  m5 = mxCreateNumericArray(1, (int32_T *)&iv10, mxDOUBLE_CLASS, mxREAL);
  mxSetData((mxArray *)m5, (void *)u->data);
  mxSetDimensions((mxArray *)m5, u->size, 1);
  emlrtAssign(&y, m5);
  return y;
}

static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *pilot, const
  char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  d_emlrt_marshallIn(sp, emlrtAlias(pilot), &thisId, y);
  emlrtDestroyArray(&pilot);
}

static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  h_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *in, const
  char_T *identifier, emxArray_creal_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  f_emlrt_marshallIn(sp, emlrtAlias(in), &thisId, y);
  emlrtDestroyArray(&in);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *in, const
  char_T *identifier, emxArray_boolean_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  b_emlrt_marshallIn(sp, emlrtAlias(in), &thisId, y);
  emlrtDestroyArray(&in);
}

static const mxArray *emlrt_marshallOut(emxArray_boolean_T *u)
{
  const mxArray *y;
  static const int32_T iv9[1] = { 0 };

  const mxArray *m4;
  y = NULL;
  m4 = mxCreateLogicalArray(1, iv9);
  mxSetData((mxArray *)m4, (void *)u->data);
  mxSetDimensions((mxArray *)m4, u->size, 1);
  emlrtAssign(&y, m4);
  return y;
}

static void f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_creal_T *y)
{
  i_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_boolean_T *ret)
{
  int32_T iv11[1];
  boolean_T bv0[1];
  int32_T iv12[1];
  iv11[0] = -1;
  bv0[0] = TRUE;
  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "logical", FALSE, 1U, iv11, bv0,
    iv12);
  ret->size[0] = iv12[0];
  ret->allocatedSize = ret->size[0];
  ret->data = (boolean_T *)mxGetData(src);
  ret->canFreeData = FALSE;
  emlrtDestroyArray(&src);
}

static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  int32_T iv13[1];
  boolean_T bv1[1];
  int32_T iv14[1];
  iv13[0] = -1;
  bv1[0] = TRUE;
  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", FALSE, 1U, iv13, bv1, iv14);
  ret->size[0] = iv14[0];
  ret->allocatedSize = ret->size[0];
  ret->data = (real_T *)mxGetData(src);
  ret->canFreeData = FALSE;
  emlrtDestroyArray(&src);
}

static void i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_creal_T *ret)
{
  int32_T iv15[1];
  boolean_T bv2[1];
  int32_T iv16[1];
  int32_T i7;
  iv15[0] = -1;
  bv2[0] = TRUE;
  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", TRUE, 1U, iv15, bv2, iv16);
  i7 = ret->size[0];
  ret->size[0] = iv16[0];
  emxEnsureCapacity(sp, (emxArray__common *)ret, i7, (int32_T)sizeof(creal_T),
                    (emlrtRTEInfo *)NULL);
  emlrtImportArrayR2011b(src, ret->data, 8, TRUE);
  emlrtDestroyArray(&src);
}

void differentially_decode_api(emlrtStack *sp, const mxArray * const prhs[1],
  const mxArray *plhs[1])
{
  emxArray_boolean_T *in;
  emxArray_boolean_T *out;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_boolean_T(sp, &in, 1, &l_emlrtRTEI, TRUE);
  emxInit_boolean_T(sp, &out, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "in", in);

  /* Invoke the target function */
  differentially_decode(sp, in, out);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(out);
  out->canFreeData = FALSE;
  emxFree_boolean_T(&out);
  in->canFreeData = FALSE;
  emxFree_boolean_T(&in);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void downmix_rds_signal_api(emlrtStack *sp, const mxArray * const prhs[2], const
  mxArray *plhs[1])
{
  emxArray_real_T *pilot;
  emxArray_real_T *rds;
  emxArray_real_T *rds_bb;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &pilot, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &rds, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &rds_bb, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "pilot", pilot);
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[1]), "rds", rds);

  /* Invoke the target function */
  downmix_rds_signal(sp, pilot, rds, rds_bb);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(rds_bb);
  rds_bb->canFreeData = FALSE;
  emxFree_real_T(&rds_bb);
  rds->canFreeData = FALSE;
  emxFree_real_T(&rds);
  pilot->canFreeData = FALSE;
  emxFree_real_T(&pilot);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void extract_pilot_api(emlrtStack *sp, const mxArray * const prhs[1], const
  mxArray *plhs[1])
{
  emxArray_real_T *bb_signal;
  emxArray_real_T *pilot;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &bb_signal, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &pilot, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "bb_signal", bb_signal);

  /* Invoke the target function */
  extract_pilot(sp, bb_signal, pilot);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(pilot);
  pilot->canFreeData = FALSE;
  emxFree_real_T(&pilot);
  bb_signal->canFreeData = FALSE;
  emxFree_real_T(&bb_signal);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void extract_rds_signal_api(emlrtStack *sp, const mxArray * const prhs[1], const
  mxArray *plhs[1])
{
  emxArray_real_T *bb_signal;
  emxArray_real_T *rds;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &bb_signal, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &rds, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "bb_signal", bb_signal);

  /* Invoke the target function */
  extract_rds_signal(sp, bb_signal, rds);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(rds);
  rds->canFreeData = FALSE;
  emxFree_real_T(&rds);
  bb_signal->canFreeData = FALSE;
  emxFree_real_T(&bb_signal);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void frequency_demodulation_api(emlrtStack *sp, const mxArray * const prhs[1],
  const mxArray *plhs[1])
{
  emxArray_creal_T *in;
  emxArray_real_T *bb;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_creal_T(sp, &in, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &bb, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  e_emlrt_marshallIn(sp, emlrtAliasP(prhs[0]), "in", in);

  /* Invoke the target function */
  frequency_demodulation(sp, in, bb);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(bb);
  bb->canFreeData = FALSE;
  emxFree_real_T(&bb);
  emxFree_creal_T(&in);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void generate_bit_clock_from_pilot_api(emlrtStack *sp, const mxArray * const
  prhs[1], const mxArray *plhs[1])
{
  emxArray_real_T *pilot;
  emxArray_real_T *bit_clk;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &pilot, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &bit_clk, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "pilot", pilot);

  /* Invoke the target function */
  generate_bit_clock_from_pilot(sp, pilot, bit_clk);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(bit_clk);
  bit_clk->canFreeData = FALSE;
  emxFree_real_T(&bit_clk);
  pilot->canFreeData = FALSE;
  emxFree_real_T(&pilot);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void lowpass_filter_rds_baseband_signal_api(emlrtStack *sp, const mxArray *
  const prhs[1], const mxArray *plhs[1])
{
  emxArray_real_T *rds_bb;
  emxArray_real_T *rds;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &rds_bb, 1, &l_emlrtRTEI, TRUE);
  emxInit_real_T(sp, &rds, 1, &l_emlrtRTEI, TRUE);

  /* Marshall function inputs */
  c_emlrt_marshallIn(sp, emlrtAlias(prhs[0]), "rds_bb", rds_bb);

  /* Invoke the target function */
  lowpass_filter_rds_baseband_signal(sp, rds_bb, rds);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(rds);
  rds->canFreeData = FALSE;
  emxFree_real_T(&rds);
  rds_bb->canFreeData = FALSE;
  emxFree_real_T(&rds_bb);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (rdstools_api.c) */
