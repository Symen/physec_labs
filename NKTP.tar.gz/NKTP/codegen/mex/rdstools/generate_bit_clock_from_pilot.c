/*
 * generate_bit_clock_from_pilot.c
 *
 * Code generation for function 'generate_bit_clock_from_pilot'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_emxutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "rdstools_data.h"

/* Variable Definitions */
static emlrtRSInfo ec_emlrtRSI = { 5, "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m" };

static emlrtRSInfo fc_emlrtRSI = { 16, "sign",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/sign.m" };

static emlrtRSInfo gc_emlrtRSI = { 13, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo hc_emlrtRSI = { 20, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo ic_emlrtRSI = { 42, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo jc_emlrtRSI = { 38, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo kc_emlrtRSI = { 37, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo lc_emlrtRSI = { 35, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo mc_emlrtRSI = { 33, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo nc_emlrtRSI = { 32, "cumsum",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo tc_emlrtRSI = { 38, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

static emlrtRSInfo uc_emlrtRSI = { 73, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

static emlrtRSInfo yc_emlrtRSI = { 84, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

static emlrtRSInfo ad_emlrtRSI = { 83, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

static emlrtRTEInfo i_emlrtRTEI = { 1, 24, "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m" };

static emlrtRTEInfo j_emlrtRTEI = { 15, 9, "eml_scalexp_alloc",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m" };

static emlrtBCInfo e_emlrtBCI = { -1, -1, 5, 32, "pilot",
  "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m", 0 };

static emlrtECInfo f_emlrtECI = { -1, 5, 32, "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m" };

static emlrtBCInfo f_emlrtBCI = { -1, -1, 5, 51, "pilot",
  "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m", 0 };

static emlrtECInfo g_emlrtECI = { -1, 5, 51, "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m" };

static emlrtECInfo h_emlrtECI = { -1, 5, 27, "generate_bit_clock_from_pilot",
  "/home/nktp/Documents/NKTP/generate_bit_clock_from_pilot.m" };

/* Function Definitions */
void generate_bit_clock_from_pilot(const emlrtStack *sp, const emxArray_real_T
  *pilot, emxArray_real_T *bit_clk)
{
  int32_T vstride;
  int32_T ixstart;
  int32_T j;
  int32_T loop_ub;
  int32_T dim;
  emxArray_real_T *x;
  int32_T k;
  emxArray_real_T *r1;
  emxArray_boolean_T *b_x;
  boolean_T b0;
  real_T xlast;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /* EXTRACT_BIT_CLOCK Summary of this function goes here */
  /*    Detailed explanation goes here */
  if (2 > pilot->size[0]) {
    vstride = 0;
    ixstart = 0;
  } else {
    vstride = 1;
    ixstart = pilot->size[0];
    j = pilot->size[0];
    ixstart = emlrtDynamicBoundsCheckFastR2012b(j, 1, ixstart, &e_emlrtBCI, sp);
  }

  emlrtVectorVectorIndexCheckR2012b(pilot->size[0], 1, 1, ixstart - vstride,
    &f_emlrtECI, sp);
  if (1 > pilot->size[0] - 1) {
    loop_ub = 0;
  } else {
    j = pilot->size[0];
    emlrtDynamicBoundsCheckFastR2012b(1, 1, j, &f_emlrtBCI, sp);
    j = pilot->size[0];
    dim = pilot->size[0] - 1;
    loop_ub = emlrtDynamicBoundsCheckFastR2012b(dim, 1, j, &f_emlrtBCI, sp);
  }

  emxInit_real_T(sp, &x, 1, &i_emlrtRTEI, TRUE);
  emlrtVectorVectorIndexCheckR2012b(pilot->size[0], 1, 1, loop_ub, &g_emlrtECI,
    sp);
  st.site = &ec_emlrtRSI;
  j = x->size[0];
  x->size[0] = ixstart - vstride;
  emxEnsureCapacity(&st, (emxArray__common *)x, j, (int32_T)sizeof(real_T),
                    &i_emlrtRTEI);
  dim = ixstart - vstride;
  for (j = 0; j < dim; j++) {
    x->data[j] = pilot->data[vstride + j];
  }

  vstride = (ixstart - vstride) - 1;
  for (k = 0; k <= vstride; k++) {
    b_st.site = &fc_emlrtRSI;
    x->data[k] = muDoubleScalarSign(x->data[k]);
  }

  emxInit_real_T(&st, &r1, 1, &i_emlrtRTEI, TRUE);
  st.site = &ec_emlrtRSI;
  vstride = r1->size[0];
  r1->size[0] = loop_ub;
  emxEnsureCapacity(&st, (emxArray__common *)r1, vstride, (int32_T)sizeof(real_T),
                    &i_emlrtRTEI);
  for (vstride = 0; vstride < loop_ub; vstride++) {
    r1->data[vstride] = pilot->data[vstride];
  }

  for (k = 0; k < loop_ub; k++) {
    b_st.site = &fc_emlrtRSI;
    r1->data[k] = muDoubleScalarSign(r1->data[k]);
  }

  emxInit_boolean_T(&st, &b_x, 1, &i_emlrtRTEI, TRUE);
  vstride = x->size[0];
  ixstart = r1->size[0];
  emlrtSizeEqCheck1DFastR2012b(vstride, ixstart, &h_emlrtECI, sp);
  st.site = &ec_emlrtRSI;
  vstride = b_x->size[0];
  b_x->size[0] = x->size[0];
  emxEnsureCapacity(&st, (emxArray__common *)b_x, vstride, (int32_T)sizeof
                    (boolean_T), &i_emlrtRTEI);
  loop_ub = x->size[0];
  for (vstride = 0; vstride < loop_ub; vstride++) {
    b_x->data[vstride] = (x->data[vstride] - r1->data[vstride] != 0.0);
  }

  emxFree_real_T(&r1);
  b_st.site = &gc_emlrtRSI;
  dim = 1;
  if (b_x->size[0] != 1) {
    dim = 0;
  }

  b_st.site = &hc_emlrtRSI;
  vstride = x->size[0];
  x->size[0] = b_x->size[0];
  emxEnsureCapacity(&b_st, (emxArray__common *)x, vstride, (int32_T)sizeof
                    (real_T), &i_emlrtRTEI);
  loop_ub = b_x->size[0];
  for (vstride = 0; vstride < loop_ub; vstride++) {
    x->data[vstride] = b_x->data[vstride];
  }

  emxFree_boolean_T(&b_x);
  if (dim + 1 <= 1) {
    loop_ub = x->size[0];
  } else {
    loop_ub = 1;
  }

  if ((!(x->size[0] == 0)) && (loop_ub > 1)) {
    c_st.site = &nc_emlrtRSI;
    vstride = 1;
    k = 1;
    while (k <= dim) {
      vstride *= x->size[0];
      k = 2;
    }

    c_st.site = &mc_emlrtRSI;
    c_st.site = &lc_emlrtRSI;
    ixstart = -1;
    c_st.site = &kc_emlrtRSI;
    if (1 > vstride) {
      b0 = FALSE;
    } else {
      b0 = (vstride > 2147483646);
    }

    if (b0) {
      d_st.site = &cb_emlrtRSI;
      check_forloop_overflow_error(&d_st);
    }

    for (j = 1; j <= vstride; j++) {
      c_st.site = &jc_emlrtRSI;
      ixstart++;
      dim = ixstart;
      xlast = x->data[ixstart];
      for (k = 0; k <= loop_ub - 2; k++) {
        c_st.site = &ic_emlrtRSI;
        dim += vstride;
        xlast += x->data[dim];
        x->data[dim] = xlast;
      }
    }
  }

  st.site = &ec_emlrtRSI;
  b_st.site = &tc_emlrtRSI;
  dim = x->size[0];
  vstride = bit_clk->size[0];
  bit_clk->size[0] = dim;
  emxEnsureCapacity(&b_st, (emxArray__common *)bit_clk, vstride, (int32_T)sizeof
                    (real_T), &j_emlrtRTEI);
  for (k = 0; k < dim; k++) {
    b_st.site = &uc_emlrtRSI;
    c_st.site = &ad_emlrtRSI;
    c_st.site = &yc_emlrtRSI;
    bit_clk->data[k] = x->data[k] - muDoubleScalarFloor(x->data[k] / 32.0) *
      32.0;
  }

  emxFree_real_T(&x);
  st.site = &ec_emlrtRSI;
  vstride = bit_clk->size[0];
  emxEnsureCapacity(sp, (emxArray__common *)bit_clk, vstride, (int32_T)sizeof
                    (real_T), &i_emlrtRTEI);
  loop_ub = bit_clk->size[0];
  for (vstride = 0; vstride < loop_ub; vstride++) {
    bit_clk->data[vstride] = (real_T)(bit_clk->data[vstride] <= 15.0) * 2.0 -
      1.0;
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (generate_bit_clock_from_pilot.c) */
