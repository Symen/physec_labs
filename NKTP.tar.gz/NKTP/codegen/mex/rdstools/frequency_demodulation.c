/*
 * frequency_demodulation.c
 *
 * Code generation for function 'frequency_demodulation'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_emxutil.h"

/* Variable Definitions */
static emlrtRSInfo bc_emlrtRSI = { 5, "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m" };

static emlrtRTEInfo h_emlrtRTEI = { 1, 19, "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m" };

static emlrtBCInfo c_emlrtBCI = { -1, -1, 5, 16, "in", "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m", 0 };

static emlrtECInfo d_emlrtECI = { -1, 5, 16, "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m" };

static emlrtBCInfo d_emlrtBCI = { -1, -1, 5, 32, "in", "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m", 0 };

static emlrtECInfo e_emlrtECI = { -1, 5, 32, "frequency_demodulation",
  "/home/nktp/Documents/NKTP/frequency_demodulation.m" };

/* Function Definitions */
void frequency_demodulation(const emlrtStack *sp, const emxArray_creal_T *in,
  emxArray_real_T *bb)
{
  int32_T i4;
  int32_T i5;
  int32_T i6;
  int32_T loop_ub;
  emxArray_creal_T *r0;
  emxArray_creal_T *x;
  real_T in_re;
  real_T in_im;
  real_T re;
  real_T im;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /* FREQUENCY_DEMODULATION Summary of this function goes here */
  /*    Detailed explanation goes here */
  if (2 > in->size[0]) {
    i4 = 1;
    i5 = 1;
  } else {
    i4 = 2;
    i5 = in->size[0];
    i6 = in->size[0];
    i5 = emlrtDynamicBoundsCheckFastR2012b(i6, 1, i5, &c_emlrtBCI, sp) + 1;
  }

  emlrtVectorVectorIndexCheckR2012b(in->size[0], 1, 1, i5 - i4, &d_emlrtECI, sp);
  if (1 > in->size[0] - 1) {
    loop_ub = 0;
  } else {
    i6 = in->size[0];
    emlrtDynamicBoundsCheckFastR2012b(1, 1, i6, &d_emlrtBCI, sp);
    i6 = in->size[0];
    loop_ub = in->size[0] - 1;
    loop_ub = emlrtDynamicBoundsCheckFastR2012b(loop_ub, 1, i6, &d_emlrtBCI, sp);
  }

  emxInit_creal_T(sp, &r0, 1, &h_emlrtRTEI, TRUE);
  emlrtVectorVectorIndexCheckR2012b(in->size[0], 1, 1, loop_ub, &e_emlrtECI, sp);
  i6 = r0->size[0];
  r0->size[0] = loop_ub;
  emxEnsureCapacity(sp, (emxArray__common *)r0, i6, (int32_T)sizeof(creal_T),
                    &h_emlrtRTEI);
  for (i6 = 0; i6 < loop_ub; i6++) {
    r0->data[i6].re = in->data[i6].re;
    r0->data[i6].im = -in->data[i6].im;
  }

  emxInit_creal_T(sp, &x, 1, &h_emlrtRTEI, TRUE);
  i6 = i5 - i4;
  loop_ub = r0->size[0];
  emlrtSizeEqCheck1DFastR2012b(i6, loop_ub, &d_emlrtECI, sp);
  st.site = &bc_emlrtRSI;
  i6 = x->size[0];
  x->size[0] = i5 - i4;
  emxEnsureCapacity(&st, (emxArray__common *)x, i6, (int32_T)sizeof(creal_T),
                    &h_emlrtRTEI);
  loop_ub = i5 - i4;
  for (i5 = 0; i5 < loop_ub; i5++) {
    in_re = in->data[(i4 + i5) - 1].re;
    in_im = in->data[(i4 + i5) - 1].im;
    re = r0->data[i5].re;
    im = r0->data[i5].im;
    x->data[i5].re = in_re * re - in_im * im;
    x->data[i5].im = in_re * im + in_im * re;
  }

  emxFree_creal_T(&r0);
  loop_ub = x->size[0];
  i4 = bb->size[0];
  bb->size[0] = loop_ub;
  emxEnsureCapacity(&st, (emxArray__common *)bb, i4, (int32_T)sizeof(real_T),
                    &h_emlrtRTEI);
  for (i4 = 0; i4 < loop_ub; i4++) {
    bb->data[i4] = 0.0;
  }

  for (loop_ub = 0; loop_ub < x->size[0]; loop_ub++) {
    bb->data[loop_ub] = muDoubleScalarAtan2(x->data[loop_ub].im, x->data[loop_ub]
      .re);
  }

  emxFree_creal_T(&x);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (frequency_demodulation.c) */
