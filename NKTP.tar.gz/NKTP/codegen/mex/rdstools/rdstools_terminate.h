/*
 * rdstools_terminate.h
 *
 * Code generation for function 'rdstools_terminate'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __RDSTOOLS_TERMINATE_H__
#define __RDSTOOLS_TERMINATE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void rdstools_atexit(emlrtStack *sp);
extern void rdstools_terminate(emlrtStack *sp);
#endif
/* End of code generation (rdstools_terminate.h) */
