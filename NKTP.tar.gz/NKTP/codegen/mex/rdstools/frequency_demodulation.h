/*
 * frequency_demodulation.h
 *
 * Code generation for function 'frequency_demodulation'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __FREQUENCY_DEMODULATION_H__
#define __FREQUENCY_DEMODULATION_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void frequency_demodulation(const emlrtStack *sp, const emxArray_creal_T *in, emxArray_real_T *bb);
#endif
/* End of code generation (frequency_demodulation.h) */
