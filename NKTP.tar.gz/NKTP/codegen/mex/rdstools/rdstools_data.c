/*
 * rdstools_data.c
 *
 * Code generation for function 'rdstools_data'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_data.h"

/* Variable Definitions */
emlrtRSInfo b_emlrtRSI = { 19, "abs",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/abs.m" };

emlrtRSInfo e_emlrtRSI = { 1, "mrdivide",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/ops/mrdivide.p" };

emlrtRSInfo f_emlrtRSI = { 15, "rdivide",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/ops/rdivide.m" };

emlrtRSInfo g_emlrtRSI = { 12, "eml_div",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_div.m" };

emlrtRSInfo h_emlrtRSI = { 16, "max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/max.m" };

emlrtRSInfo i_emlrtRSI = { 18, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo j_emlrtRSI = { 59, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo k_emlrtRSI = { 124, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo l_emlrtRSI = { 131, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo m_emlrtRSI = { 137, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo n_emlrtRSI = { 138, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo o_emlrtRSI = { 139, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo p_emlrtRSI = { 140, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo q_emlrtRSI = { 141, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo r_emlrtRSI = { 144, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo s_emlrtRSI = { 145, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo t_emlrtRSI = { 167, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo u_emlrtRSI = { 168, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo v_emlrtRSI = { 164, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo w_emlrtRSI = { 170, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo x_emlrtRSI = { 179, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo y_emlrtRSI = { 182, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo ab_emlrtRSI = { 12, "isfinite",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elmat/isfinite.m" };

emlrtRSInfo bb_emlrtRSI = { 9, "eml_int_forloop_overflow_check",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

emlrtRSInfo cb_emlrtRSI = { 12, "eml_int_forloop_overflow_check",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

emlrtRSInfo db_emlrtRSI = { 42, "eml_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/eml_xaxpy.m" };

emlrtRSInfo eb_emlrtRSI = { 25, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo fb_emlrtRSI = { 19, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo gb_emlrtRSI = { 16, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo hb_emlrtRSI = { 40, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo ib_emlrtRSI = { 39, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo jb_emlrtRSI = { 36, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo kb_emlrtRSI = { 37, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo lb_emlrtRSI = { 31, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo mb_emlrtRSI = { 28, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo nb_emlrtRSI = { 27, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo ob_emlrtRSI = { 68, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo pb_emlrtRSI = { 69, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo qb_emlrtRSI = { 70, "eml_blas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xaxpy.m"
};

emlrtRSInfo rb_emlrtRSI = { 24, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo sb_emlrtRSI = { 23, "eml_refblas_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xaxpy.m"
};

emlrtRSInfo tb_emlrtRSI = { 88, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo ub_emlrtRSI = { 225, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo vb_emlrtRSI = { 221, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo wb_emlrtRSI = { 200, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo xb_emlrtRSI = { 194, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo yb_emlrtRSI = { 190, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo cc_emlrtRSI = { 13, "angle",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/angle.m" };

emlrtRSInfo dc_emlrtRSI = { 7, "eml_scalar_angle",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/eml_scalar_angle.m" };

emlrtRSInfo oc_emlrtRSI = { 86, "eml_matrix_vstride",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_matrix_vstride.m" };

emlrtRSInfo pc_emlrtRSI = { 50, "prodsize",
  "/usr/local/MATLAB/R2013b/toolbox/shared/coder/coder/+coder/+internal/prodsize.m"
};

emlrtRSInfo qc_emlrtRSI = { 49, "prodsize",
  "/usr/local/MATLAB/R2013b/toolbox/shared/coder/coder/+coder/+internal/prodsize.m"
};

emlrtRSInfo rc_emlrtRSI = { 16, "eml_matrix_npages",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_matrix_npages.m" };

emlrtRSInfo sc_emlrtRSI = { 55, "prodsize",
  "/usr/local/MATLAB/R2013b/toolbox/shared/coder/coder/+coder/+internal/prodsize.m"
};

emlrtRSInfo vc_emlrtRSI = { 93, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

emlrtRSInfo wc_emlrtRSI = { 90, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

emlrtRSInfo xc_emlrtRSI = { 89, "mod",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/mod.m" };

emlrtMCInfo emlrtMCI = { 47, 9, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtMCInfo b_emlrtMCI = { 44, 19, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtMCInfo e_emlrtMCI = { 41, 9, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtMCInfo f_emlrtMCI = { 38, 19, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtMCInfo g_emlrtMCI = { 74, 9, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtMCInfo h_emlrtMCI = { 73, 19, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRTEInfo d_emlrtRTEI = { 115, 1, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRTEInfo f_emlrtRTEI = { 1, 14, "eml_xaxpy",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/blas/eml_xaxpy.m" };

emlrtRSInfo dd_emlrtRSI = { 73, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo ed_emlrtRSI = { 38, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo fd_emlrtRSI = { 44, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

emlrtRSInfo id_emlrtRSI = { 74, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo jd_emlrtRSI = { 41, "eml_min_or_max",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/eml/eml_min_or_max.m" };

emlrtRSInfo kd_emlrtRSI = { 47, "filter",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/datafun/filter.m" };

/* End of code generation (rdstools_data.c) */
