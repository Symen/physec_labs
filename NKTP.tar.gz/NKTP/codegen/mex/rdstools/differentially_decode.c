/*
 * differentially_decode.c
 *
 * Code generation for function 'differentially_decode'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "differentially_decode.h"
#include "downmix_rds_signal.h"
#include "extract_pilot.h"
#include "extract_rds_signal.h"
#include "frequency_demodulation.h"
#include "generate_bit_clock_from_pilot.h"
#include "lowpass_filter_rds_baseband_signal.h"
#include "rdstools_emxutil.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 5, "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m" };

static emlrtRTEInfo emlrtRTEI = { 1, 20, "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m" };

static emlrtRTEInfo b_emlrtRTEI = { 16, 5, "abs",
  "/usr/local/MATLAB/R2013b/toolbox/eml/lib/matlab/elfun/abs.m" };

static emlrtBCInfo emlrtBCI = { -1, -1, 5, 15, "in", "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m", 0 };

static emlrtECInfo emlrtECI = { -1, 5, 15, "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m" };

static emlrtBCInfo b_emlrtBCI = { -1, -1, 5, 25, "in", "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m", 0 };

static emlrtECInfo b_emlrtECI = { -1, 5, 25, "differentially_decode",
  "/home/nktp/Documents/NKTP/differentially_decode.m" };

/* Function Definitions */
void differentially_decode(const emlrtStack *sp, const emxArray_boolean_T *in,
  emxArray_boolean_T *out)
{
  int32_T i0;
  int32_T i1;
  int32_T loop_ub;
  int32_T i2;
  emxArray_real_T *x;
  emxArray_real_T *y;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /* DECODE_RDS_BITSTREAM Summary of this function goes here */
  /*    Detailed explanation goes here */
  if (2 > in->size[0]) {
    i0 = 1;
    i1 = 1;
  } else {
    i0 = 2;
    i1 = in->size[0];
    loop_ub = in->size[0];
    i1 = emlrtDynamicBoundsCheckFastR2012b(loop_ub, 1, i1, &emlrtBCI, sp) + 1;
  }

  emlrtVectorVectorIndexCheckR2012b(in->size[0], 1, 1, i1 - i0, &emlrtECI, sp);
  if (1 > in->size[0] - 1) {
    loop_ub = 0;
  } else {
    loop_ub = in->size[0];
    emlrtDynamicBoundsCheckFastR2012b(1, 1, loop_ub, &b_emlrtBCI, sp);
    loop_ub = in->size[0];
    i2 = in->size[0] - 1;
    loop_ub = emlrtDynamicBoundsCheckFastR2012b(i2, 1, loop_ub, &b_emlrtBCI, sp);
  }

  emxInit_real_T(sp, &x, 1, &emlrtRTEI, TRUE);
  emlrtVectorVectorIndexCheckR2012b(in->size[0], 1, 1, loop_ub, &b_emlrtECI, sp);
  i2 = i1 - i0;
  emlrtSizeEqCheck1DFastR2012b(i2, loop_ub, &emlrtECI, sp);
  st.site = &emlrtRSI;
  loop_ub = x->size[0];
  x->size[0] = i1 - i0;
  emxEnsureCapacity(&st, (emxArray__common *)x, loop_ub, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  loop_ub = i1 - i0;
  for (i1 = 0; i1 < loop_ub; i1++) {
    x->data[i1] = (real_T)in->data[(i0 + i1) - 1] - (real_T)in->data[i1];
  }

  emxInit_real_T(&st, &y, 1, &emlrtRTEI, TRUE);
  loop_ub = x->size[0];
  i0 = y->size[0];
  y->size[0] = loop_ub;
  emxEnsureCapacity(&st, (emxArray__common *)y, i0, (int32_T)sizeof(real_T),
                    &b_emlrtRTEI);
  for (loop_ub = 0; loop_ub < x->size[0]; loop_ub++) {
    y->data[loop_ub] = muDoubleScalarAbs(x->data[loop_ub]);
  }

  emxFree_real_T(&x);
  i0 = out->size[0];
  out->size[0] = y->size[0];
  emxEnsureCapacity(sp, (emxArray__common *)out, i0, (int32_T)sizeof(boolean_T),
                    &emlrtRTEI);
  loop_ub = y->size[0];
  for (i0 = 0; i0 < loop_ub; i0++) {
    out->data[i0] = (y->data[i0] > 0.0);
  }

  emxFree_real_T(&y);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (differentially_decode.c) */
