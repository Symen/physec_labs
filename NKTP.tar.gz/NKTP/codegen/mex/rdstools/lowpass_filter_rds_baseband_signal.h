/*
 * lowpass_filter_rds_baseband_signal.h
 *
 * Code generation for function 'lowpass_filter_rds_baseband_signal'
 *
 * C source code generated on: Wed Nov  6 17:47:30 2013
 *
 */

#ifndef __LOWPASS_FILTER_RDS_BASEBAND_SIGNAL_H__
#define __LOWPASS_FILTER_RDS_BASEBAND_SIGNAL_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "rdstools_types.h"

/* Function Declarations */
extern void lowpass_filter_rds_baseband_signal(const emlrtStack *sp, const emxArray_real_T *rds_bb, emxArray_real_T *rds);
#endif
/* End of code generation (lowpass_filter_rds_baseband_signal.h) */
