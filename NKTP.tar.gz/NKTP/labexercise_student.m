%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Global settings                                                       %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

% The sampling rate of our baseband signal has to be 190 kHz and should
% not be changed if the precompiled rdstools used for testing should work.
fs = 190000;

% Sampling frequency of the frequency modulated signal
fs_fm = 400000;

% Function to plot the fft including the correct frequency axis
plotfft = @(x,fs,b) ...
    plot(linspace(-fs/2,fs/2,length(x)),abs(fftshift(fft(x)))/length(x),b);

tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 1: Bitstream Generation                                          %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 1: Generation of Bitstream %.2f\n', toc);
% Define groups (one block per row, without checkword) according to table 1

% Repeat defined groups

% Generate checkword for each group

% Reshape output to bitstream
%bitstream = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 2: Differential Encoding                                         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 2: Differential Encoding %.2f\n', toc);
% Differentially encode the bitstream according to table 2
%bitstream_differentially_encoded = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 3: Manchester Encoding                                           %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 3: Manchester Encoding %.2f\n', toc);
% Generate a 1186.5 Hz bit clock that is sampled at 190 kHz as a
% rectangular waveform. This signal is required for the "Task 3 Test".
% Bitrate is 190 kHz / 160 = 1187.5 Hz
%bit_clk = ...;

% Take the differentaially encoded bitstream from Task 2 and map it to
% Manchester Encoded symbols. A binary zero become a -1 to +1 transition, a
% binary one a +1 to -1 transition.

% Lowpass filter the generated RDS signal with a cutoff frequency of 2400
% Hz and normalize it
%rds_filt = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 4: Generate Baseband Signal                                      %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 4: Generate Baseband Signal %.2f\n', toc);
% The baseband signal consists of an RDS signal at 57 kHz, a pilot at 19
% kHz and optionally mono or stereo audio signals. We will create a mono
% signal from the audio file you brought with you.

% Generate a 19 kHz sine wave sampled at 190 kHz. The length of the signal
% vector should be equal to the length of rds_filt

% Generate a 57 kHz sine wave similar to and in phase with the 19 kHz pilot
% tone

% Mix up the filtered RDS signal to 57 kHz by multiplying with the
% generated 57 kHz sine wave;



% Read your audio file

% Sum up the left and the right audio channel to create a mono signal

% Lowpass filter the audio signal with a cutoff frequency of 15 kHz. Take
% the audio files sampling rate into account!

% Resample the audio signal to the baseband sampling rate of 190 kHz. The
% resampled audio signal should be as long as the rds_up signal. Therefore,
% you roughly need floor(length(rds_up)/(floor(fs/wavfs*10)/10)) samples of
% the original audio signal

% Normalize the audio signal to an amplitude of one




% combine the 19 kHz pilot, the upmixed rds signal and the audio signal
% into the baseband signal
%bb = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 5: Frequency Modulation                                          %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 5: Frequency Modulation %.2f\n', toc);
%fm = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 6: Radio Spectrum Analysis                                       %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start analysing the spectrum using baudline
%!./baudline.sh <center frequency> <sampling rate> &

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 7: Transmission by USRP                                          %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 6: Transmission by USRP %.2f\n', toc);
% Initialize an object of the SDRuTransmitter: set the USRPs IP address,
% the carrier frequency for our radio channel, the gain and the
% interpolation factor as the USRPs DACs work at 100 MHz
%hSDRutx = comm.SDRuTransmitter('192.168.10.2', ...
%        'CenterFrequency',        <center frequency>, ...
%        'Gain',                   10, ...
%        'InterpolationFactor',    <interpolation factor>);

% Cut the fm signal into 1000 sample pieces and send them to the USRP
%for i = 1:floor(length(fm)/1000)
%    step(hSDRutx,fm((1:1000)+(i-1)*1000));
%end

% Release the SDRuTransmitter Object as we do not need it anymore
%release(hSDRutx);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 8: Radio Reception                                               %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Capture an radio transmission with rtl_sdr

%% Read the captured samples and convert to signed numbers

%% Separate inphase and quadrature components and normalize

%% Change the sampling rate to fs_fm
%fm = ...;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 5 Test: FM Demodulation                                          %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 5 Test: FM Demodulation %.2f\n', toc);
%f1 = fir1(300,80000/fs_fm*2);
%fm = filter(f1,1,fm);
%bb_res = rdstools('frequency_demodulation',fm);
%bb = resample(bb_res,fs,fs_fm);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 4 Test: Disassemble Baseband Signal                              %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 4 Test: Disassemble Baseband Signal %.2f\n', toc);
% Extract RDS signal
% Use a bandpass filter from 54 to 60 kHz to extract the RDS signal around
% 57 kHz
%rds_rx = rdstools('extract_rds_signal',bb);

% Extract pilot
% Use a bandpass filter from 18500 to 19500 Hz to extract the 19 kHz pilot 
% signal
%pilot = rdstools('extract_pilot',bb);

% Mix the RDS signal (around 57 kHz) down
% Tripple the pilots frequency by multiplication by itself and multiply
% with the bandpass filtered RDS siganl around 57 kHz
%rds_bb = rdstools('downmix_rds_signal',pilot, rds_rx);

% Lowpass filter RDS baseband signal
% Generate a Lowpass filter with cutoff frequency 2400 Hz
%rds_filt = rdstools('lowpass_filter_rds_baseband_signal',rds_bb);

% Generate bit clock
% Take the 19 kHz pilot signal and reduce its frequency by a factor of 16
% to get the 1187.5 Hz bit clock signal
%bit_clk = rdstools('generate_bit_clock_from_pilot',pilot);

% Optionally extract and play audio signal
%extract_and_play_mono_audio(bb);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 3 Test: Manchester Decoding and Synchronization                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 3 Test: Manchester Decoding and Synchronization %.2f\n', toc);
% Sometimes the block processing size has to change to successfully
% synchronize and decode RDS messages, which is due to the implementation
% we used. Try numbers around 512.
%bitstream_differentially_encoded = ...
%    rdsdecode(rds_filt, bit_clk, fs, 505)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 2 Test: Differential Decoding                                    %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 2 Test: Differential Decoding %.2f\n', toc);
%bitstream = rdstools('differentially_decode',bitstream_differentially_encoded>0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Task 1 Test: Information Extraction                                   %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fprintf('Task 1 Test: Information Extraction %.2f\n', toc);
%rdsdecode(bitstream > 0,'172.16.62.197');