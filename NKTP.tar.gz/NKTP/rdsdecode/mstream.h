/*
 * based on: http://stackoverflow.com/questions/243696/correctly-over-loading-a-stringbuf-to-replace-cout-in-a-matlab-mex-file
 */

#include <stdio.h>
#include <iostream>

class mstream : public std::streambuf {
public:
protected:
  virtual std::streamsize xsputn(const char *s, std::streamsize n);
  virtual int overflow(int c = EOF);
};
