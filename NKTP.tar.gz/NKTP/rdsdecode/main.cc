/*
 * main.cc
 *
 *  Created on: 11.10.2013
 *      Author: matthias
 */

#include "gr_rds_data_decoder_standalone.h"
#include <stdio.h>
#include <fcntl.h>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include "charsym.h"
#include "charsym_diff.h"

int main() {
	gr_rds_data_decoder rds("127.0.0.1", 1234);

	int size = 1;
	int d_output_multiple = 104;

	char in[104*10];
	char out;
	gr_vector_const_void_star input_items(1);
	gr_vector_void_star output_items(1);
	input_items[0] = (void *) &in;
	output_items[0] = (void *) &out;

	//printf("%p %p %08x\n",(void *) &input_items, &input_items[0], input_items[0]);

	std::ifstream file ("charsym_diff.bin", std::ios::in|std::ios::binary|std::ios::ate);
	if (file.is_open())
	{
		file.seekg (0, std::ios::beg);
		while(!file.eof()) {
			file.read(&in[0], d_output_multiple * size);
			rds.work(d_output_multiple * size, input_items, output_items);
		}
		file.close();
	}

	/*
	while(!std::cin.eof()) {
		std::cin.read(&in[0], d_output_multiple * size);
		rds.work(d_output_multiple * size, input_items, output_items);
	}
	*/
/*
	unsigned int i = 0;
	while (true) {
		input_items[0] = (void *) &charsym_diff_bin[i];
		rds.work(d_output_multiple * size, input_items, output_items);

		if (i < charsym_diff_bin_len - d_output_multiple)
			i += d_output_multiple * size;
		else
			break;//i = 0;
	}
*/
	return 0;
}

