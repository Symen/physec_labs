#ifdef MATLAB_MEX_FILE
#include <mex.h>
#include "gr_rds_data_decoder_standalone.h"
#include "gr_rds_bpsk_demod.h"
#include "mstream.h"

void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[]) {
    // Set the cout output to MATLAB console
    mstream mout;
    std::streambuf *outbuf = std::cout.rdbuf(&mout);

    mexPrintf("\n==============================================\n");
    mexPrintf("rdsdecode - based on gr-rds\n");
    mexPrintf("Version: 0.1 - %s %s\n", __DATE__, __TIME__);
    mexPrintf("==============================================\n\n");

    if (nrhs >= 1 && mxIsLogical(prhs[0])) {
    	gr_rds_data_decoder *rds;
    	gr_vector_const_void_star input_items(1);
        gr_vector_void_star output_items(1);
        char out;

		input_items[0] = mxGetData(prhs[0]);
		output_items[0] = (void *) &out;

    	if (nrhs == 3 && mxIsChar(prhs[1]) && mxIsDouble(prhs[2])) {
    		rds = new gr_rds_data_decoder(mxArrayToString(prhs[1]), mxGetScalar(prhs[2]));
    	} else if (nrhs == 2 && mxIsChar(prhs[1])) {
    		rds = new gr_rds_data_decoder(mxArrayToString(prhs[1]), 1234);
    	} else {
    		rds = new gr_rds_data_decoder("127.0.0.1", 1234);
    	}

		rds->work(mxGetNumberOfElements(prhs[0]), input_items, output_items);

		delete rds;
    }

    if (nlhs == 1 && nrhs == 4 && mxIsDouble(prhs[0]) && mxIsDouble(prhs[1]) && mxIsDouble(prhs[2]) && mxIsDouble(prhs[3])) {
    	gr_rds_bpsk_demod demod(mxGetScalar(prhs[2]));
    	gr_vector_int demod_ninput_items(2);
    	gr_vector_const_void_star demod_input_items(2);
    	gr_vector_void_star demod_output_items(1);
    	gr_vector_int demod_nconsumed_items(2);
    	int items_per_run = mxGetScalar(prhs[3]);
    	int rds_all_cnt = mxGetNumberOfElements(prhs[0]);
    	int clk_all_cnt = mxGetNumberOfElements(prhs[1]);
    	int nout = 0;
    	int rds_cnt = 0;
    	int clk_cnt = 0;
    	plhs[0] = mxCreateLogicalMatrix(1,rds_all_cnt/demod.get_symbol_length());
    	mxLogical *out = mxGetLogicals(plhs[0]);
    	double **rds_p = (double **) &demod_input_items[0];
    	double **clk_p = (double **) &demod_input_items[1];

    	demod_ninput_items[0] = items_per_run;
    	demod_ninput_items[1] = items_per_run;
    	demod_input_items[0] = mxGetData(prhs[0]);
    	demod_input_items[1] = mxGetData(prhs[1]);
    	demod_output_items[0] = out;
    	demod_nconsumed_items[0] = 0;
    	demod_nconsumed_items[1] = 0;

		while (rds_cnt + items_per_run < rds_all_cnt && clk_cnt + items_per_run < clk_all_cnt) {
			demod_nconsumed_items[0] = 0;
			demod_nconsumed_items[1] = 0;
			demod_output_items[0] = out;

			nout = demod.general_work(0, demod_ninput_items, demod_input_items,
										demod_output_items, demod_nconsumed_items);
			mexPrintf("--- %d %d %d rds_p=%p clk_p=%p rds_cnt=%d clk_cnt=%d\n",
					demod_nconsumed_items[0], demod_nconsumed_items[1], nout, rds_p, clk_p, rds_cnt, clk_cnt);

			*rds_p += demod_nconsumed_items[0];
			*clk_p += demod_nconsumed_items[1];
			rds_cnt += demod_nconsumed_items[0];
			clk_cnt += demod_nconsumed_items[1];
			out += nout;
    	}
    }

    // Reset the cout output
    std::cout.rdbuf(outbuf);
}
#endif

