#!/bin/bash
g++ -DMATLAB_MEX_FILE -DDEBUG -I/usr/local/MATLAB/R2013b/extern/include -fPIC -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"gr_rds_bpsk_demod.d" -MT"gr_rds_bpsk_demod.d" -o "gr_rds_bpsk_demod.o" "../gr_rds_bpsk_demod.cc"
 
g++ -DMATLAB_MEX_FILE -DDEBUG -I/usr/local/MATLAB/R2013b/extern/include -fPIC -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"gr_rds_data_decoder_standalone.d" -MT"gr_rds_data_decoder_standalone.d" -o "gr_rds_data_decoder_standalone.o" "../gr_rds_data_decoder_standalone.cc"
 
g++ -DMATLAB_MEX_FILE -DDEBUG -I/usr/local/MATLAB/R2013b/extern/include -fPIC -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"main.d" -MT"main.d" -o "main.o" "../main.cc"

g++ -DMATLAB_MEX_FILE -DDEBUG -I/usr/local/MATLAB/R2013b/extern/include -fPIC -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"mexfunction.d" -MT"mexfunction.d" -o "mexfunction.o" "../mexfunction.cc"

g++ -DMATLAB_MEX_FILE -DDEBUG -I/usr/local/MATLAB/R2013b/extern/include -fPIC -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"mstream.d" -MT"mstream.d" -o "mstream.o" "../mstream.cc"

g++ -L/usr/local/MATLAB/R2013b/bin/glnxa64 -shared -o "rdsdecode.mexa64"  ./gr_rds_bpsk_demod.o ./gr_rds_data_decoder_standalone.o ./main.o ./mexfunction.o ./mstream.o   -lmex -lmat -lmx
