/* -*- c++ -*- */
/*
 * Copyright 2004 Free Software Foundation, Inc.
 *
 * This file is part of GNU Radio
 *
 * GNU Radio is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * GNU Radio is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Radio; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/*	HSR - MOBKOM LABOR
 *	Semesterarbeit GnuRadio Contributions
 *	U. Schaufelberger and R. Gaensli
 *
 * 	Written by : Ronnie Gaensli
 * 	Created: 2005/05
 *
 */


#ifndef INCLUDED_gr_rds_bpsk_demod_H
#define INCLUDED_gr_rds_bpsk_demod_H

#include <iostream>
#include <fstream>
#include <vector>

typedef std::vector<void *>			gr_vector_void_star;
typedef std::vector<const void *>		gr_vector_const_void_star;
typedef std::vector<int> gr_vector_int;

class gr_rds_bpsk_demod;

/*!
 * \brief Decodes a biphase or manchester coded signal to 1, 0 as bool
 * \ingroup RDS
 */
class gr_rds_bpsk_demod
{
private:
	enum state_t { ST_LOOKING, ST_LOCKED };
	state_t d_state;
	int SYMBOL_LENGTH;
	int d_zc;				// Zero crosses in clk
	int d_last_zc;
	int d_sign_last;
	double d_symbol_integrator;
	unsigned int synccounter;

	void enter_looking();
	void enter_locked();

public:
	gr_rds_bpsk_demod (double input_samping_rate);
	~gr_rds_bpsk_demod ();
	int general_work (int noutput_items,
		gr_vector_int &ninput_items,
		gr_vector_const_void_star &input_items,
		gr_vector_void_star &output_items,
		gr_vector_int &nconsumed_items);
	void reset(int r);
	int get_symbol_length();
};

#endif /* INCLUDED_gr_rds_bpsk_demod_H */
